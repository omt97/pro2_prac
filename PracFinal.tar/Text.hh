/** @file Text.hh
    @brief Especificació de la classe Text
*/

#ifndef TEXT_HH
#define TEXT_HH

#include "Frase.hh"

#ifndef NO_DIAGRAM
#include <utility>
#include <map>
#endif


/** @class Text

    @brief Representa un conjunt de frases ordenat per aparicio en el canal d'entrada.
    Es poden consultar i modificar els seus elements (de tipus Frase)
    donat una frase concreta o per posicio a l'ordre
    */

class Text {

private:

  vector<Frase> text;
  vector<string> vtitol;
  vector<string> vautor;
  map<string, int> freq;
  string Titol;
  int nFrases;
  int nParaules;
  /*
    Invariant de la representacio:
    - text[0..nfrase-1] esta ordenat per aparicio en el canal d'entrada
    - 0 <= n_frases <= vfrase.size()
    - nFrases i nParaules mai son negatius.
  */

	/** @brief Calcula freq a cada modificacio de la classe
      \pre contingut es valid
      \post el resultat es el vector freq amb totes les paraules de la classe
			ordenades en funcio del numero de aparicions
  */
	void calcular_freq(list<string>& contingut);

  /** @brief La paraula p que existeix en el text, es substituida dins de freq per
              q.
      \pre p existeix i q es valid
      \post el resultat es el vector freq pero la paraula p es substituida per q.
  */
  void canvi_freq(string p, string q);

public:

  //Constructores

  /** @brief Creadora per defecte.
      S'executa automaticament al declarar Text t;
      \pre cert
      \post el resultat es un conjunt de frases buit on nFrases = 0 i nParaules = 0,
              freq i Titol són conjunts buits.
  */
 Text();


    //Modificador

    /** @brief El vector Titol, pasa a estar ple, i és igual al vector cridat
              per referencia.

        \pre titol es vàlid
        \post el vector Titol és igual al vector cridat per referencia, anomenat titol.
     */
  void afegir_titol(string& titol);

  void afegir_vtitol(vector<string>& titol);

  void afegir_vautor(vector<string>& autor);

  /** @brief La llista contingut es descompon en les seves diverses frases,
              les quals són usades per formar el vector text.

        \pre frase es vàlida
        \post el vector text esta format per les frases que hi ha en la llista
              contingut, a nFrases se li suma el nombre de frases que s'afegeixen
              , i a nParaules se li sumen el nombre de paraules de cada frase.
    */
  void crea_text (list<string>& contingut);

  /** @brief En l'ultim text triat es canvien totes els paraules que siguin igual a p per la paraula q. Llavors dins
            de la taula de freqüencia del text es substitueix la paraula p per la q.

      \pre el parametre implicit conté la paraula p i q es una paraula vàlida
      \post totes les aparicions de p en el parametre implicit han pasat a ser q.
            I la paraula p que apareix en freq es canviada per q.
   */
  void cambiar_paraula(string p, string q);

    //Consultores

  /** @brief Consulta el numero de frases del text

      \pre cert
      \post el resultat es el numero de frases (nFrases) del parametre implicit
   */
  int consultar_nFrases();

  /** @brief Consulta el numero total de paraules del text.

      \pre cert
      \post el resultat es el numero total de paraules (nParaules) de la classe.
   */
  int consultar_nParaules();

  /** @brief Cerca d'un conjunt de paraules en la classe

      \pre par es vàlid
      \post el resultat indica si el text conté les paraules del vector par.
   */
   bool te_paraules(vector<string>& par);

   /** @brief La funció retorna la taula de freqüencies del text, on la taula de freqüencies és una
             taula que conté totes les paraules del text i el nombre d'aparicions que tenen, la taula està
             ordenada per ordre d'aparicions, (de més a menys).
       \pre cert.
       \post el resultat es la taula de freqüencies del text.
   */
 map<string, int> obtenir_freq();

  /** @brief Crea un string que conté el Titol de la classe Text

      \pre cert
      \post el resultat es un string que conté el Titol de la classe
  */
  string consultar_titol();

  void sec_paraules(vector<string>& sec);

  /** @brief Crea un vector que conté el Titol de la classe Text

      \pre cert
      \post el resultat es un vector que conté el Titol de la classe
  */
  vector<string> consultar_vtitol();

  /** @brief Crea un vector que conté el autor de la classe Text

      \pre cert
      \post el resultat es un vector que conté el autor de la classe
  */
  vector<string> consultar_vautor();

  /** @brief La funció retorna un vector que conté les frases del text, on apareixen les paraules
            del vector paraules.
      \pre paraules és valid.
      \post el resultat es una seqüencia de frases, del text, que contenen les paraules del vector
            paraules.
  */
vector<Frase> obtenir_frases_par(vector<string>& paraules);

/** @brief La funció retorna un vector que conté les frases del text, que hi ha entre
            la x-essima i la y-essima (incloses).
    \pre x i y són valides.
    \post el resultat es una seqüencia de frases, del text, que estan entre la x-essima
          i la y-essima (incloses).
*/
vector<Frase> obtenir_frases(int x, int y);

  // Lectura i escriptura


  /** @brief Operacio d'escriptura

    \pre cert
    \post s'han escrit pel canal estandard de sortida totes les frases de la
		classe per ordre d'entrada
   */
  void escriure();

};
#endif
