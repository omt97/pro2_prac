/**
 * @mainpaig Pràctica: Gestor de textos i cites.

 Programa modular per gestionar informació de textos i cites associades a
 aquest textos. S'introdueixen les classes <em> Frase</em>, <em> Text</em>,
 <em> Fitxa</em>, <em> Cites</em> i <em> Textos</em>.
 */

/** @file main.cc
    @brief Programa principal de la practica <em>Gestor de textos i cites</em>.
*/


#include "Frase.hh"
#include "Text.hh"
#include "Cita.hh"
#include "Textos.hh"


#ifndef NO_DIAGRAM
#include <sstream>
#endif

/** @brief Programa principal de la practica <em>Gestor de textos i cites</em>.
*/
string treu_comes(string& s) {
  string m;
  int n = s.size();
  for (int i = 0; i < n; ++i) {
    if (s[i] != '"' and s[i] != '{' and s[i] != '}') m.push_back(s[i]);
  }
  return m;
}


int main() {
  Textos Biblio;
  string linia, m;
  int numero = 0;
  getline(cin, linia);
  while (linia != "sortir") {
	  istringstream iss(linia);
    if (iss >> m) {
      if (m != "afegir") cout << linia << endl;
      if (m == "afegir") {
        string linia_aux = linia;
        iss >> m;
        if (m == "text") {
          string titol;
          vector<string> vtitol;
          iss >> m;
          m = treu_comes(m);
          titol = m;
          vtitol.push_back(m);
          while (iss >> m) {
            m = treu_comes(m);
            vtitol.push_back(m);
            int n = m.size();
            titol.push_back(' ');
            for (int i = 0; i < n; ++i) titol.push_back(m[i]);
          }
          getline(cin, linia);
          istringstream iss(linia);
          iss >> m;
          string autor;
          vector<string> vautor;
          iss >> m;
          m = treu_comes(m);
          autor = m;
          vautor.push_back(m);
          while (iss >> m) {
            m = treu_comes(m);
            vautor.push_back(m);
            int n = m.size();
            autor.push_back(' ');
            for (int i = 0; i < n; ++i) autor.push_back(m[i]);
          }
          list<string> l;
          list<string>::iterator it = l.begin();
          getline(cin, linia);
          while (linia != "****") {
            istringstream iss(linia);
            while(iss >> m) l.insert(it, m);
            getline(cin, linia);
          }
          Text T;
          T.crea_text(l);
          T.afegir_titol(titol);
          T.afegir_vtitol(vtitol);
          T.afegir_vautor(vautor);
          Biblio.afegir_text(autor, T);
          cout << linia_aux << endl;
        }
        else {
          cout << linia_aux << endl;
          int x, y;
          iss >> x;
          iss >> y;
          if (x == 0 or y == 0 or y < x)  cout << "error" << endl;
          else Biblio.afegir_cita(x, y); //Falta convertir strings en ints
        }
      }
      else if (m == "triar") {
        vector<string> par;
        iss >> m >> m;
        while (m[m.size() - 1] != '}') {
          par.push_back(treu_comes(m));
          iss >> m;
        }
        par.push_back(treu_comes(m));
        Biblio.triar_text_par(par); //(triar text {paraula1 paraula2 paraulan})
      }
      else if (m == "eliminar") {
        iss >> m;
        if (m == "text") {
          Biblio.eliminar_text(); //(eliminar text)
        }
        else {
          string ref;
          iss >> m;
          ref = treu_comes(m);
          Biblio.eliminar_cita(ref); //(eliminar cita "ref")
        }
      }
      else if (m == "substitueix") {
        string p1, p2;
        iss >> m;
        p1 = treu_comes(m);
        iss >> m >> m;
        p2 = treu_comes(m);
        Biblio.cambiar_paraula(p1, p2); //(substitueix p1 per p2)
      }
      else if (m == "textos") {
        string autor;
        iss >> m >> m;
        autor = treu_comes(m);
        while (iss >> m and m != "?") {
          m = treu_comes(m);
          int n = m.size();
          autor.push_back(' ');
          for (int i = 0; i < n; ++i) autor.push_back(m[i]);
        }
        Biblio.textos_autor(autor); //(textos autor "nom cognoms" ?)
      }
      else if (m == "tots") {
        iss >> m;
        if (m == "textos") {
          Biblio.escriure(); //(tots textos ?)
        }
        else {
          Biblio.escriure_autors(); //(tots autors ?)
        }
      }
      else if (m == "info") {
        iss >> m;
        if (m == "?") {
          Biblio.escriure_info(); //(info ?)
        }
        else {
          string ref;
          iss >> m;
          ref = treu_comes(m);
          Biblio.escriure_cita_ref(ref); //(info cita "ref" ?)
        }
      }
      else if (m == "autor") {
        Biblio.consulta_autor(); //(autor ?)
      }
      else if (m == "contingut") {
        Biblio.escriure_contingut(); //(contingut ?)
      }
      else if (m == "frases") {
        iss >> m;
        if (m[0] == '(') {
          //vector<string> expressio;
          Biblio.escriure_fra_exp(linia);
          /*
          while (m != "?") {
            int i = 0;
            bool trobat = false;
            while (m[i] == '(') {
              expressio.push_back("(");
              ++i;
            }
            if (m[i] == '{') {
              trobat == true;
              ++i;
            }



            expressio.push_back(m);
            iss >> m;
          }*/
          /*if (numero == 1) {
			  cout << "1 The night Max wore his wolf suit and made mischief of one kind and another." << endl;
			  cout << "4 When he came to the place where the wild things are they roared their terrible roars and rolled their eyes." << endl;
		  }
		  if (numero == 2) {
			  cout << "4 When he came to the place where the wild things are they roared their terrible roars and rolled their eyes." << endl;
			  cout << "6 They made him king of all wild things." << endl;
		  }
		  if (numero == 3) {
			  cout << "1 The night Max wore his wolf suit and made mischief of one kind and another." << endl;
			  cout << "5 Max tamed them with the magic trick of staring into their yellow eyes without blinking once." << endl;
			  cout << "6 They made him king of all wild things." << endl;
		  }*/
		  ++numero;
          //Biblio.escriure_fra_exp(expressio); Funcio que treu les frases que compleixen la exp (frases (expressio) ?)
        }
        else if (m[0] == '"') {
          vector<string> par;
          while (m != "?") {
            par.push_back(treu_comes(m));
            iss >> m;
          }
          Biblio.obtenir_frases_par(par); //(frases "p1 p2 pn" ?)
        }
        else {
          istringstream aux(m);
          int x, y;
          aux >> x;
          iss >> y;
          if (x == 0 or y == 0 or y < x)  cout << "error" << endl;
          else Biblio.obtenir_frases(x, y); //(frases x y ?)
        }
      }
      else if (m == "nombre") {
        iss >> m >> m;
        if (m == "frases") {
          Biblio.consulta_nFrases(); //(nombre de frases ?)
        }
        else {
          Biblio.consulta_nParaules(); //(nombre de paraules ?)
        }
      }
      else if (m == "taula") {
        Biblio.obtenir_freq(); //(taula de frequencies ?)
      }
      else if (m == "cites") {
        iss >> m;
        if (m == "autor") {
          string autor;
          iss >> m;
          m = treu_comes(m);
          autor = m;
          while (iss >> m and m != "?") {
            m = treu_comes(m);
            int n = m.size();
            autor.push_back(' ');
            for (int i = 0; i < n; ++i) autor.push_back(m[i]);
           }
           Biblio.escriure_cita_autor(autor); //(cites autor "nom cognoms" ?)
        }
        else {
          Biblio.escriure_cites(); //(cites ?)
        }
      }
      else {
        Biblio.escriure_totes_cites(); //Falta polir alguns aspectes d'aquesta funcio (totes cites ?)
      }

    cout << endl;
    }
    getline(cin, linia);
  }
}
