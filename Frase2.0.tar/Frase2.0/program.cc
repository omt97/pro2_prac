#include "Frase.hh"


int main() {
  Frase f1, f2;
  cout << f1.consultar_nParaules() << ' ' << f2.consultar_nParaules() << endl;
  string p1, p2;
  cin >> p1;
  cout << f1.te_paraula(p1) << ' ' << f2.te_paraula(p1) << endl;
  cin >> p2;
  cout << f1.te_paraula(p2) << ' ' << f2.te_paraula(p2) << endl;
  list<string> l1, l2;
  list<string>::iterator it = l1.begin();
  string s;
  cin >> s;
  while (s != "fi") {
    l1.insert(it, s);
    cin >> s;
  }
  it = l2.begin();
  cin >> s;
  while (s != "fi") {
    l2.insert(it, s);
    cin >> s;
  }
  f1.afegir_frase(l1);
  f2.afegir_frase(l2);
  cout << f1.consultar_nParaules() << ' ' << f2.consultar_nParaules() << endl;
  cin >> p1;
  cout << f1.te_paraula(p1) << ' ' << f2.te_paraula(p1) << endl;
  cin >> p2;
  cout << f1.te_paraula(p2) << ' ' << f2.te_paraula(p2) << endl;
  f1.escriure();
  f2.escriure();
  cin >> p1;
  cin >> p2;
  f1.cambiar_paraula(p1, p2);
  cin >> p1;
  cin >> p2;
  f2.cambiar_paraula(p1, p2);
  f1.escriure();
  f2.escriure();
  cout << f1.consultar_nParaules() << ' ' << f2.consultar_nParaules() << endl;
}
