#include "Text.hh"


int main() {
  Text f1, f2;
  cout << f1.consultar_nParaules() << ' ' << f2.consultar_nParaules() << endl;
  cout << f1.consultar_nFrases() << ' ' << f2.consultar_nFrases() << endl;
  vector<string> p1(2), p2(2);
  cin >> p1[0] >> p1[1];
  cin >> p2[0] >> p2[1];
  f1.afegir_titol(p1);
  f2.afegir_titol(p2);
  cout << f1.consultar_nParaules() << ' ' << f2.consultar_nParaules() << endl;
  cout << f1.consultar_nFrases() << ' ' << f2.consultar_nFrases() << endl;
  cout << f1.consultar_titol()[0] << ' ' << f1.consultar_titol()[1] << endl;
  cout << f2.consultar_titol()[0] << ' ' << f2.consultar_titol()[1] << endl;
  list<string> l1, l2;
  list<string>::iterator it = l1.begin();
  string s;
  cin >> s;
  while (s != "fi") {
    l1.insert(it, s);
    cin >> s;
  }
  it = l2.begin();
  cin >> s;
  while (s != "fi") {
    l2.insert(it, s);
    cin >> s;
  }
  f1.crea_text(l1);
  cout << "freq 1:" << endl;
  map<string, int> freq1 = f1.obtenir_freq();
  for (map<string, int>::iterator i = freq1.begin(); i != freq1.end(); ++i) {
    cout << i->first << ' ' << i->second << endl;
  }
  f2.crea_text(l2);
  cout << "freq 2:" << endl;
  map<string, int> freq2 = f2.obtenir_freq();
  for (map<string, int>::iterator i = freq2.begin(); i != freq2.end(); ++i) {
    cout << i->first << ' ' << i->second << endl;
  }
  cout << f1.consultar_nParaules() << ' ' << f2.consultar_nParaules() << endl;
  cout << f1.consultar_nFrases() << ' ' << f2.consultar_nFrases() << endl;
  cin >> p1[0] >> p1[1];
  cout << f1.te_paraules(p1) << ' ' << f2.te_paraules(p1) << endl;
  cin >> p2[0] >> p2[1];
  cout << f1.te_paraules(p2) << ' ' << f2.te_paraules(p2) << endl;
  f1.escriure();
  f2.escriure();
  string x, y;
  cin >> x;
  cin >> y;
  f1.cambiar_paraula(x, y);
  cin >> x;
  cin >> y;
  f2.cambiar_paraula(x, y);
  f1.escriure();
  f2.escriure();
  cout << f1.consultar_nParaules() << ' ' << f2.consultar_nParaules() << endl;
  cout << f1.consultar_nFrases() << ' ' << f2.consultar_nFrases() << endl;
  cout << "freq 1:" << endl;
  freq1 = f1.obtenir_freq();
  for (map<string, int>::iterator i = freq1.begin(); i != freq1.end(); ++i) {
    cout << i->first << ' ' << i->second << endl;
  }
  cout << "freq 2:" << endl;
  freq2 = f2.obtenir_freq();
  for (map<string, int>::iterator i = freq2.begin(); i != freq2.end(); ++i) {
    cout << i->first << ' ' << i->second << endl;
  }
  cin >> p1[0] >> p1[1];
  vector<Frase> par = f1.obtenir_frases_par(p1);
  for (int i = 0; i < par.size(); ++i) par[i].escriure();
  cin >> p2[0] >> p2[1];
  par = f1.obtenir_frases_par(p2);
  for (int i = 0; i < par.size(); ++i) par[i].escriure();
}
