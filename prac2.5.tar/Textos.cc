#include "Textos.hh"
#include <stack>
/*
string Textos::calcular_ref(string& autor){
    string ref;
    char ll = autor[0];
    if (ll <= 'z' and ll >= 'a'){
        ll == ll - 32;
    }
    ref.push_back(ll);
    for (int i = 1; i < autor.size(); ++i){
        if (autor[i] == ' ' and (i + 1) != autor.size()){
            ll = autor[i + 1];
            if (ll <= 'z' and ll >= 'a'){
                ll == ll - 32;
            }
            ref.push_back(ll);
        }
    }
    map<string, Cita>::const_iterator it;
    int num = 0;
    for (it = Cites.begin(); it != Cites.end(); ++it){
        string ref2 = it->first;
        int i = 0;
        string rref;
        while (ref2[i] <= 'Z' and ref2[i] >= 'A'){
            rref.push_back(ref2[i]);
            ++i;
        }
        int mida = ref2.size() - rref.size();
        if (ref == rref){
            ++num;
        }
    }
    string num2;
    int i = 0;
    stack<char> p;
    while (num >= 1){
        num = num/(i*10);
        int n = num%10;
        p.push(n);
        ++i;
    }
    while (not p.empty()){
        ref.push_back(p.top());
        p.pop();
    }
    return ref;
}

void Textos::calc_vec_freq(Text& text){
    map<string, int> freq = text.obtenir_freq();
    map<string, int>::iterator it;
    while (not freq.empty()){
        int i = 0;
        map<string, int>::iterator it2;
        for (it = freq.begin(); it != freq.end(); ++it){
            if (it->second > i){
                i = it->second;
                it2 = it;
            }
            else if (it->second == i){
                if (it->first < it2->first){
                    it2 = it;
                }
            }
        }
        ultim.freq_v.push_back(make_pair(it2->second, it2->first));
        freq.erase(it2);
    }
}

void Textos::canvi_freq_v(string p, string q){
    bool trobat = false;
    int i = 0;
    while (not trobat and i < ultim.freq_v.size()){
        if (ultim.freq_v[i].second == p){
            trobat = true;
            ultim.freq_v[i].second = q;
        }
    }
}
*/
Textos::Textos(){
    nAutor = 0;
    nText = 0;
    ultim.esta = false;
}

bool Textos::esta_autor(string& autor){
    map<string, list<Text> >::iterator it = textos.find(autor);
    if (it != textos.end()) return true;
    else return false;
}

void Textos::triar_text_par(vector<string>& paraules){
    map<string, list<Text> >::iterator it = textos.begin();
    bool trobat = false;
    ultim.esta = false;
    while (not trobat and it != textos.end()){
        list<Text>::iterator t_it = it->second.begin();
        while (not trobat and t_it != it->second.end()){
            trobat = (*t_it).te_paraules(paraules);
            if (trobat){
                ultim.ult = make_pair(it->first, *t_it);
                //calc_vec_freq(*t_it);
                ultim.esta = true;
            }
            ++t_it;
        }
        ++it;
    }
}

void Textos::textos_autor(string& autor){
    map<string, list<Text> >::iterator it = textos.find(autor);
    list<Text>::iterator it_l = it->second.begin();
    while (it_l != it->second.end()){
        cout << '"' << (*it_l).consultar_titol() << '"' << endl;
        ++it_l;
    }
}

void Textos::consulta_autor(){
    if (not ultim.esta) cout << "error" << endl;
    else cout << ultim.ult.first << endl;
}

void Textos::consulta_nFrases(){
    if (ultim.esta) cout << ultim.ult.second.consultar_nFrases() << endl;
    else cout << "error" << endl;
}

void Textos::consulta_nParaules(){
  if (ultim.esta) cout << ultim.ult.second.consultar_nParaules() << endl;
  else cout << "error" << endl;
}
/*
vector<Frase> Textos::obtenir_frases(int x, int y){
    if (not ultim.esta) cout << "error" << endl;
    else{
        vector<Frase> fra(y - x);
        pair <string, Text> par;
        par = ultim.ult;
        Text tex;
        tex = par.second;
        fra = tex.obtenir_frases(x, y);
        return fra;
    }
}

vector<pair<int, string> > Textos::obtenir_freq(){
    if (not ultim.esta) cout << "error" << endl;
    else{
        return ultim.freq_v;
    }
}

vector<Frase> Textos::obtenir_frases_par(vector<string>& paraules){
    if (not ultim.esta) cout << "error" << endl;
    else{
        pair<string, Text> par;
        par = ultim.ult;
        Text tex;
        tex = par.second;
        return tex.obtenir_frases_par(paraules);
    }
}
*/
void Textos::afegir_text(string& autor, Text& text){
    map<string, list<Text> >::iterator it;
    it = textos.find(autor);
    if (it != textos.end()){
        list<Text>::iterator it2 = it->second.begin();
        string titol = text.consultar_titol();
        bool fi = true;
        while (fi and it2 != it->second.end()){
            if (text.consultar_titol() < (*it2).consultar_titol()) {
              it->second.insert(it2, text);
              fi = false;
            }
            else ++it2;
        }
        if (fi) it->second.insert(it2, text);
    }
    else{
        list<Text> ll_tex;
        list<Text>::iterator it3 = ll_tex.begin();
        ll_tex.insert(it3, text);
        textos.insert(make_pair(autor, ll_tex));
        ++nAutor;
    }
    ++nText;
}

void Textos::eliminar_text(){
    if (not ultim.esta) cout << "error" << endl;
    else{
        map<string, list<Text> >::iterator it_m = textos.find(ultim.ult.first);
        list<Text>::iterator it_l = it_m->second.begin();
        bool borrat = false;
        while (not borrat and it_l != it_m->second.end()){
            Text t = *it_l;
            string tit2 = (*it_l).consultar_titol();
            if (ultim.ult.second.consultar_titol() == (*it_l).consultar_titol()){
                it_l = it_m->second.erase(it_l);
                borrat = true;
            }
        }
        --nText;
        if (it_m->second.empty()){
            textos.erase(it_m);
            --nAutor;
        }
        ultim.esta = false;
  }
}

void Textos::cambiar_paraula(string p, string q){
    if (not ultim.esta) cout << "error" << endl;
    else{
        ultim.ult.second.cambiar_paraula(p, q);
        map<string, list<Text> >::iterator it_m = textos.find(ultim.ult.first);
        list<Text>::iterator it_l = it_m->second.begin();
        bool cambiat = false;
        while (not cambiat and it_l != it_m->second.end()){
            if (ultim.ult.second.consultar_titol() == (*it_l).consultar_titol()){
                (*it_l).cambiar_paraula(p, q);
            }
            ++it_l;
        }
        //canvi_freq_v(p, q); //crear-la
    }
}
/*
void Textos::afegir_cita(int x, int y){
    vector<Frase> v_fra = ultim.ult.second.obtenir_frases(x, y);
    string autor = ultim.ult.first;
    string ref = calcular_ref(autor);
    map<string, Cita>::iterator it = Cites.begin();
    bool trobat = false;
    while (not trobat and it != Cites.begin()){
        string tit = it->second.consultar_Titol();
        string aut = it->second.consultar_Autor();
        if (tit == ultim.ult.second.consultar_titol() and aut == ultim.ult.first){
            int x1 = it->second.consultar_fra_in();
            int y1 = it->second.consultar_fra_fi();
            if (x1 == x  and y1 == y) trobat = true;
        }
    }
    if (not trobat){
      Cita cita;
      cita.afegir_frases(v_fra, x, y);
      string t = ultim.ult.second.consultar_titol();
      cita.afegir_tit_aut(t, autor);
    }
    else cout << "error, la cita ja existeix" << endl;
}

void Textos::eliminar_cita(string& referencia){
    map<string, Cita>::iterator it;
    it = Cites.find(referencia);
    Cites.erase(it);
}
*/
void Textos::escriure(){
    map<string, list<Text> >::iterator it;
    for (it = textos.begin(); it != textos.end(); ++it){
        list<Text>::iterator it2;
        for (it2 = it->second.begin(); it2 != it->second.end(); ++it2){
            cout << it->first << ' ';
            cout << '"' << (*it2).consultar_titol() << '"' << endl;
        }
    }
}

void Textos::escriure_autors(){
    map<string, list<Text> >::iterator it;
    for (it = textos.begin(); it != textos.end(); ++it){
        cout << it->first;
        int nPar = 0;
        int nFra = 0;
        int nTex = 0;
        list<Text>::iterator it2;
        for (it2 = it->second.begin(); it2 != it->second.end(); ++it2){
            ++nTex;
            nPar += (*it2).consultar_nParaules();
            nFra += (*it2).consultar_nFrases();
        }
        cout << ' ' << nTex << ' ' << nFra << ' ' << nPar << endl;
    }
}
/*
void Textos::escriure_info(){
  string aut = ultim.ult.first;
  string tit = ultim.ult.second.consultar_titol();
  cout << "autor: ";
  for (int i = 0; i < aut.size(); ++i){
      if (aut[i] == '.') aut[i] = ' ';
      cout << aut[i];
  }
  cout << endl;
  cout << "titol: ";
  for (int j = 0; j < tit.size(); ++j){
      if (tit[j] == '.') tit[j] = ' ';
      cout << tit[j];
  }
  cout << endl;
  cout << "nombre de paraules: " << ultim.ult.second.consultar_nParaules();
  cout << "nombre de frases: " << ultim.ult.second.consultar_nFrases();
  map<string, Cita>::iterator it;
  cout << "cites: " << endl;
  for (it = Cites.begin(); it != Cites.end(); ++it){
      if (it->second.consultar_Autor() == aut){
          if (it->second.consultar_Titol() == tit){
              vector<Frase> frases = it->second.consultar_cita();
              for (int i = 0; i < frases.size(); ++i){
                  frases[i].escriure();
              }
          }
      }
  }
}
*/
void Textos::escriure_contingut(){
    if (ultim.esta) ultim.ult.second.escriure();
    else cout << "error" << endl;
}
/*
void Textos::escriure_cita_ref(string& ref){
    map<string, Cita>::iterator it;
    it = Cites.find(ref);
    string aut = it->second.consultar_Autor();
    string tit = it->second.consultar_Titol();
    vector<Frase> frases = it->second.consultar_cita();
    for (int i = 0; i < frases.size(); ++i){
        frases[i].escriure();
    }
    cout << "autor: ";
    for (int i = 0; i < aut.size(); ++i){
        if (aut[i] == '.') aut[i] = ' ';
        cout << aut[i];
    }
    cout << endl;
    cout << "titol: ";
    for (int j = 0; j < tit.size(); ++j){
        if (tit[j] == '.') tit[j] = ' ';
        cout << tit[j];
    }
    cout << endl;
    cout << "valor frase inicial: " << it->second.consultar_fra_in() << endl;
    cout << "valor frase final: " << it->second.consultar_fra_fi() << endl;
}

void Textos::escriure_cita_autor(string& autor){
    map<string, Cita>::iterator it;
    for (it = Cites.begin(); it != Cites.end(); ++it){
        if (autor == it->second.consultar_Autor()){
            cout << "referencia: " << it->first << endl;
            string tit = it->second.consultar_Titol();
            cout << "titol: ";
            for (int i = 0; i < tit.size(); ++i){
                if (tit[i] == '.') tit[i] = ' ';
                cout << tit[i];
            }
            cout << endl;
            cout << "cita: ";
            vector<Frase> cita = it->second.consultar_cita();
            for (int j = 0; j < cita.size(); ++j){
                cita[j].escriure();
            }
        }
    }
}

void Textos::escriure_cites(){
  string aut = ultim.ult.first;
  string tit = ultim.ult.second.consultar_titol();
  map<string, Cita>::iterator it;
  for (it = Cites.begin(); it != Cites.end(); ++it){
      if (it->second.consultar_Autor() == aut){
          if (it->second.consultar_Titol() == tit){
              vector<Frase> frases = it->second.consultar_cita();
              for (int i = 0; i < frases.size(); ++i){
                  frases[i].escriure();
              }
              cout << "autor: ";
              for (int i = 0; i < aut.size(); ++i){
                  if (aut[i] == '.') aut[i] = ' ';
                  cout << aut[i];
              }
              cout << endl;
              cout << "titol: ";
              for (int j = 0; j < tit.size(); ++j){
                  if (tit[j] == '.') tit[j] = ' ';
                  cout << tit[j];
              }
              cout << endl;
          }
      }
  }
}

void Textos::escriure_totes_cites(){
    map<string, Cita>::iterator it;
    for (it = Cites.begin(); it != Cites.end(); ++it){
        vector<Frase> cita = it->second.consultar_cita();
        string tit = it->second.consultar_Titol();
        string aut = it->second.consultar_Autor();
        cout << "referencia: " << it->first << endl;
        cout << "titol: ";
        for (int i = 0; i < tit.size(); ++i){
            if (tit[i] == '.') tit[i] = ' ';
            cout << tit[i];
        }
        cout << endl;
        bool first = true;
        cout << "autor: ";
        for (int j = 0; j < aut.size(); ++j){
            if (aut[j] == '.') aut[j] = ' ';
            cout << aut[j];
        }
        for (int u = 0; u < cita.size(); ++u){
            cita[u].escriure();
        }
    }
}
*/
