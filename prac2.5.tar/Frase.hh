/** @file Frase.hh
    @brief Especificació de la classe Frase
*/

#ifndef FRASE_HH
#define FRASE_HH

#ifndef NO_DIAGRAM
#include <iostream>
#include <string>
#include <vector>
#include <list>
using namespace std;
#endif


// Tipus de modul: dades

/** @class  Frase
    @brief Representa una frase de paraules.
    Les paraules nomes poden contenir caracters ascii < 128
*/

class Frase {


private:
  vector<string> frase;
  int nParaules;

  /*
    Invariant de la representació:
    - 0 <= nParaules
  */
public:
  //Constructores

  /** @brief Creadora per defecte.
      S'executa automáticament al declarar Frase f.
      \pre cert
      \post el resultat es una frase buida amb nParaules = 0.
  */
  Frase();


  //Modificadores

  /** @brief Substitueix la paraula p per q en tota la frase

      \pre el parametre implicit te p i q es una paraula valida
      \post totes les aparicions de p en el parametre implicit han pasat a ser q
   */
  void cambiar_paraula(string p, string q);

  /** @brief El vector frase es aquella part del vector contingut que va desde el
            primer element fins aquell que acaba amb un '.','!','?'. nParaules
            es igual al nombre de paraules afegides.
        \pre contingut és vàlid
        \post el vector frase conté aquella part de la llista contingut que va
              desde el primer element fins aquell que acaba amb un '.','!','?'.
              nParaules es igual al nombre de paraules afegides, contingut perd
              les paraules afegides.
    */
  void afegir_frase(list<string>& contingut);


  //Consultores

  /** @brief Consulta del nombre de paraules (nParaules) del parametre implicit

      \pre cert
      \post el resultat es el nombre de paraules (nParaules) del parametre implicit
   */
  int consultar_nParaules();

  /** @brief Comprova si el parametre implicit te la paraula p

      \pre p es una paraula valida
      \post el resultat indica si el parametre implicit te p o no
   */
  bool te_paraula(string p);


  // Lectura i escriptura

  /** @brief Operació d'escriptura

      \pre cert
      \post s'han escrit els atributs del parametre implicit
     al canal estandard de sortida
   */
  void escriure();
};
#endif
