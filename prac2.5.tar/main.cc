/**
 * @mainpaig Pràctica: Gestor de textos i cites.

 Programa modular per gestionar informació de textos i cites associades a
 aquest textos. S'introdueixen les classes <em> Frase</em>, <em> Text</em>,
 <em> Fitxa</em>, <em> Cites</em> i <em> Textos</em>.
 */

/** @file main.cc
    @brief Programa principal de la practica <em>Gestor de textos i cites</em>.
*/


#include "Frase.hh"
#include "Text.hh"
#include "Cita.hh"
#include "Textos.hh"


#ifndef NO_DIAGRAM
#include <sstream>
#endif

/** @brief Programa principal de la practica <em>Gestor de textos i cites</em>.
*/
string treu_comes(string& s) {
  string m;
  int n = s.size();
  for (int i = 0; i < n; ++i) {
    if (s[i] != '"' and s[i] != '{' and s[i] != '}') m.push_back(s[i]);
  }
  return m;
}


int main() {
  Textos Biblio;
  string linia, m;
  getline(cin, linia);
  while (linia != "sortir") {
    cout << linia << endl;
	  istringstream iss(linia);
    iss >> m;
    if (m == "afegir") {
      iss >> m;
      if (m == "text") {
        string titol;
        iss >> m;
        m = treu_comes(m);
        titol = m;
        while (iss >> m) {
          m = treu_comes(m);
          int n = m.size();
          titol.push_back(' ');
          for (int i = 0; i < n; ++i) titol.push_back(m[i]);
        }
        getline(cin, linia);
        istringstream iss(linia);
        iss >> m;
        string autor;
        iss >> m;
        m = treu_comes(m);
        autor = m;
        while (iss >> m) {
          m = treu_comes(m);
          int n = m.size();
          autor.push_back(' ');
          for (int i = 0; i < n; ++i) autor.push_back(m[i]);
        }
        list<string> l;
        list<string>::iterator it = l.begin();
        getline(cin, linia);
        while (linia != "****") {
          istringstream iss(linia);
          while(iss >> m) l.insert(it, m);
          getline(cin, linia);
        }
        Text T;
        T.crea_text(l);
        T.afegir_titol(titol);
        Biblio.afegir_text(autor, T);
      }
      else {
        string x, y;
        iss >> x;
        iss >> y;
        //afegir_cita(x, y); Falta convertir strings en ints
      }
    }
    else if (m == "triar") {
      vector<string> par;
      iss >> m >> m;
      while (m[m.size() - 1] != '}') {
        par.push_back(treu_comes(m));
        iss >> m;
      }
      par.push_back(treu_comes(m));
      Biblio.triar_text_par(par); //(triar text {paraula1 paraula2 paraulan})
    }
    else if (m == "eliminar") {
      iss >> m;
      if (m == "text") {
        Biblio.eliminar_text(); //(eliminar text)
      }
      else {
        string ref;
        iss >> m;
        ref = treu_comes(m);
        //eliminar_cita(ref); (eliminar cita "ref")
      }
    }
    else if (m == "substitueix") {
      string p1, p2;
      iss >> m;
      p1 = treu_comes(m);
      iss >> m >> m;
      p2 = treu_comes(m);
      Biblio.cambiar_paraula(p1, p2); //(substitueix p1 per p2)
    }
    else if (m == "textos") {
      string autor;
      iss >> m >> m;
      autor = treu_comes(m);
      while (iss >> m and m != "?") {
        m = treu_comes(m);
        int n = m.size();
        autor.push_back(' ');
        for (int i = 0; i < n; ++i) autor.push_back(m[i]);
      }
      Biblio.textos_autor(autor); //(textos autor "nom cognoms" ?)
    }
    else if (m == "tots") {
      iss >> m;
      if (m == "textos") {
        Biblio.escriure(); //(tots textos ?)
      }
      else {
        Biblio.escriure_autors(); //(tots autors ?)
      }
    }
    else if (m == "info") {
      iss >> m;
      if (m == "?") {
        //escriure_info(); (info ?)
      }
      else {
        string ref;
        iss >> m;
        ref = treu_comes(m);
        //escriu_cita_ref(ref); (info cita "ref" ?)
      }
    }
    else if (m == "autor") {
      Biblio.consulta_autor(); //(autor ?)
    }
    else if (m == "contingut") {
      Biblio.escriure_contingut(); //(contingut ?)
    }
    else if (m == "frases") {
      iss >> m;
      if (m[0] == '(') {
        vector<string> expressio;
        while (m != "?") {
          expressio.push_back(m);
          iss >> m;
        }
        //frases_exp(expressio); Funcio que treu les frases que compleixen la exp (frases (expressio) ?)
      }
      else if (m[0] == '"') {
          vector<string> par;
          while (m != "?") {
            par.push_back(treu_comes(m));
            iss >> m;
          }
          //escriu_frasesp(par); (frases "p1 p2 pn" ?)
      }
      else {
        string x, y;  //Falta trobar manera X i Y siguin ints i no strings
        x = m;
        iss >> m;
        y = m;
        //obtenir_frases(x, y); (frases x y ?)
      }
    }
    else if (m == "nombre") {
      iss >> m >> m;
      if (m == "frases") {
        Biblio.consulta_nFrases(); //(nombre de frases ?)
      }
      else {
        Biblio.consulta_nParaules(); //(nombre de paraules ?)
      }
    }
    else if (m == "taula") {
      //escriure_freq(); (taula de frequencies ?)
    }
    else if (m == "cites") {
      iss >> m;
      if (m == "autor") {
          vector<string> autor;
          while (iss >> m and m != "?") autor.push_back(treu_comes(m));
          //escriu_cites_aut(autor); (cites autor "nom cognoms" ?)
      }
      else {
        //escriure_cites(); (cites ?)
      }
    }
    else {
      //totes_cites(); Falta polir alguns aspectes d'aquesta funcio (totes cites ?)
    }
    getline(cin, linia);
  }
}
