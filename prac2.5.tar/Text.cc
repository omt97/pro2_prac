#include "Text.hh"

/*Funciona 10/10*/
//Potser no la opcio mes rapida (cerca dicotommica?)
void Text::calcular_freq(list<string>& contingut){
    list<string>::const_iterator i;
    map<string, int>::iterator it = freq.begin();
    for (i = contingut.begin(); i != contingut.end(); ++i){
      string p, p1;
      p = *i;
      int n = p.size() - 1;
      if ((p[0] < 'a' or p[0] > 'z') and (p[0] < 'A' or p[0] > 'Z') and (p[0] < '0' or p[0] > '9')){
        for(int k = 1; k < n - 1; ++k) p1.push_back(p[k]);
      }
      else {
        p1.push_back(p[0]);
        for(int k = 1; k < n - 1; ++k) p1.push_back(p[k]);
      }
      if ((p[n] >= 'a' and p[n] <= 'z') or (p[n] >= 'A' and p[n] <= 'Z') or (p[n] >= '0' and p[n] <= '9')){
        if (n > 1) p1.push_back(p[n - 1]);
        if (n > 0) p1.push_back(p[n]);
      }
      else {
        if ((n > 1) and ((p[n - 1] >= 'a' and p[n - 1] <= 'z') or (p[n - 1] >= 'A' and p[n - 1] <= 'Z') or (p[n - 1] >= '0' and p[n - 1] <= '9'))) {
          p1.push_back(p[n - 1]);
        }
      }
      it = freq.find(p1);
      if (it == freq.end()){
          freq[p1];
          it = freq.find(p1);
          it->second = 1;
      }
      else it->second = it->second + 1;
    }
}

/*Funciona 10/10*/
void Text::canvi_freq(string p, string q){
    map<string, int>::iterator it;
    it = freq.find(p);
    if (it != freq.end()){
      int elem = it->second;
      freq.erase(it);
      freq.insert(make_pair(q, elem));
    }
}

/*Funciona 10/10*/
Text::Text(){
    nFrases = 0;
    nParaules = 0;
}

/*Funciona 10/10*/
void Text::afegir_titol(string& titol){
    Titol = titol;
}

/*Funciona 10/10*/
//No es la manera mes optima
void Text::crea_text (list<string>& contingut){
   calcular_freq(contingut);
    while (not contingut.empty()){
        Frase frase;
        frase.afegir_frase(contingut);
        nParaules += frase.consultar_nParaules();
        ++nFrases;
        text.push_back(frase);
    }
}

/*Funciona 10/10*/
void Text::cambiar_paraula(string p, string q){
    int size = text.size();
    for (int i = 0; i < size; ++i){
        text[i].cambiar_paraula(p, q);
    }
    canvi_freq(p, q);
}

/*Funciona 10/10*/
int Text::consultar_nFrases(){
    return nFrases;
}

/*Funciona 10/10*/
int Text::consultar_nParaules(){
    return nParaules;
}

/*Funciona 9/10*/
//No diferencia entre "" i {}
bool Text::te_paraules(vector<string>& par){
    bool estan = true;
    int size_t = text.size();
    int size_p = par.size();
    int j = 0;
    while (estan  and j < size_p){
        string p = par[j];
        bool esta = false;
        int i = 0;
        while (not esta and i < size_t){
            if (text[i].te_paraula(p)) esta = true;
            else ++i;
        }
        if (esta) ++j;
        else estan = false;
        }
    return estan;
}

/*Funciona 10/10*/
map<string, int> Text::obtenir_freq(){
    return freq;
}

/*Funciona 10/10*/
string Text::consultar_titol(){
    return Titol;
}

/*Funciona 9/10*/
//Les paraules han de ser corelatives
vector<Frase> Text::obtenir_frases_par(vector<string>& paraules){
    vector<Frase> fra;
    int size_t = text.size();
    int size_p = paraules.size();
    for (int i = 0; i < size_t; ++i){
        int j = 0;
        bool esta = true;
        while (esta  and j < size_p){
            if (not text[i].te_paraula(paraules[j])) esta = false;
            else ++j;
        }
        if (esta) fra.push_back(text[i]);
    }
    return fra;
}

vector<Frase> Text::obtenir_frases(int x, int y){
    vector<Frase> fra;
    for (int i = x; i <= y; ++i){
        fra.push_back(text[i]);
    }
    return fra;
}

/*Funciona 10/10*/
void Text::escriure(){
    int size_t = text.size();
    for (int i = 0; i < size_t; ++i){
        cout << i+1 << ' ';
        text[i].escriure();
    }
}
