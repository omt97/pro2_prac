#include "Frase.hh"


Frase::Frase() {
    nParaules = 0;
}

void Frase::afegir_frase (list<string>& contingut) {
    if (not contingut.empty()) {
        nParaules = 0;
        list<string>::iterator it = contingut.begin();
        string par = *it;
        char ultima = par[par.size() - 1];
        while (ultima != '.' and ultima != '?' and ultima != '!') {
            if (par == ";" or par == ":" or par == ",") {
              int n = frase.size() - 1;
              char s = par[0];
              frase[n].push_back(s);
              it = contingut.erase(it);
              par = *it;
              ultima = par[par.size() - 1];
            }
            else {
              frase.push_back(*it);
              it = contingut.erase(it);
              par = *it;
              ultima = par[par.size() - 1];
              ++nParaules;
            }
        }
        if ((nParaules != 0) or ((*it).size() > 1)) ++nParaules;
        if ((*it).size() > 1) {
          frase.push_back(*it);
          it = contingut.erase(it);
        }
        else {
          int n = frase.size() - 1;
          char s = par[0];
          frase[n].push_back(s);
          it = contingut.erase(it);
        }
    }
}

void Frase::cambiar_paraula(string p, string q) {
  int size = frase.size();
  string par;
  for (int i = 0; i < size; ++i) {
	string p1, q1;
    par = frase[i];
    int n = par.size() - 1;
    if ((par[0] < 'a' or par[0] > 'z') and (par[0] < 'A' or par[0] > 'Z') and (par[0] < '0' or par[0] > '9')) {
	  p1.push_back(par[0]);
	  q1.push_back(par[0]);
	  int m = p.size();
	  for(int i = 0; i < m; ++i) p1.push_back(p[i]);
	  int k = q.size();
	  for(int i = 0; i < k; ++i) q1.push_back(q[i]);
	}
	else {
      p1 = p;
	  q1 = q;
	}
    if ((par[n] < 'a' or par[n] > 'z') and (par[n] < 'A' or par[n] > 'Z') and (par[n] < '0' or par[n] > '9')) {
      if ((n > 2) and (par[n - 1] < 'a' or par[n - 1] > 'z') and (par[n - 1] < 'A' or par[n - 1] > 'Z') and (par[n - 1] < '0' or par[n - 1] > '9')) {
		p1.push_back(par[n - 1]);
		q1.push_back(par[n - 1]);
	  }
	  p1.push_back(par[n]);
	  q1.push_back(par[n]);
	}
    if (par == p1) frase[i] = q1;
  }
}

int Frase::consultar_nParaules() {
    return nParaules;
}

bool Frase::te_paraula(string p) {
    int size = frase.size();
    string par;
    for (int i = 0; i < size; ++i) {
		string p1;
        par = frase[i];
        int n = par.size() - 1;
        if ((par[0] < 'a' or par[0] > 'z') and (par[0] < 'A' or par[0] > 'Z') and (par[0] < '0' or par[0] > '9')) {
	      p1.push_back(par[0]);
	      int m = p.size();
	      for(int i = 0; i < m; ++i) p1.push_back(p[i]);
	    }
	    else p1 = p;
        if ((par[n] < 'a' or par[n] > 'z') and (par[n] < 'A' or par[n] > 'Z') and (par[n] < '0' or par[n] > '9')) {
          if ((par[n - 1] < 'a' or par[n - 1] > 'z') and (par[n - 1] < 'A' or par[n - 1] > 'Z') and (par[n - 1] < '0' or par[n - 1] > '9')) {
		    p1.push_back(par[n - 1]);
		  }
		  p1.push_back(par[n]);
        }
        if (par == p1) return true;
    }
    return false;
}

bool Frase::apareix_sec_par(vector<string>& sec) {
  int nsec = sec.size() - 1;
  int nfra = frase.size() - 1;
  for (int i = 0; i <= nfra - nsec; ++i) {
    bool trobat = false;
    for (int j = 0; j <= nsec; ++j) {
      if (frase[i+j] == sec[j]) trobat = true;
      else {
        string par = frase[i + j];
        string sec_aux = sec[j];
        int n = par.size() - 1;
        if ((par[n] < 'a' or par[n] > 'z') and (par[n] < 'A' or par[n] > 'Z') and (par[n] < '0' or par[n] > '9')) {
          sec_aux.push_back(par[n]);
        }
        if (par == sec_aux) trobat = true;
        else {
          trobat = false;
          j = nsec + 1;
        }
      }
    }
    if (trobat) return true;
  }
  return false;
}

void Frase::escriure() {
  int size = frase.size();
  cout << frase[0];
  for (int i = 1; i < size; ++i) {
      cout << ' ' << frase[i];
  }
  cout << endl;
}
