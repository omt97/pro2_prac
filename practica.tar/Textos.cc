#include "Textos.hh"
#include <stack>
#include <sstream>

string Textos::calcular_ref(string& autor) {
    string ref;
    char ll = autor[0];
    if (ll <= 'z' and ll >= 'a') {
        ll = (int(ll) - int('a')) + int('A');
    }
    ref.push_back(ll);
    for (int i = 1; i < autor.size(); ++i) {
        if (autor[i] == ' ' and (i + 1) != autor.size()) {
            ll = autor[i + 1];
            if (ll <= 'z' and ll >= 'a'){
                ll = (int(ll) - int('a')) + int('A');
            }
            ref.push_back(ll);
        }
    }
    char num = '0';
    if (not vref.empty()) {
      int n = vref.size();
      for (int i = 0; i < n; ++i) {
        if (ref == vref[i].first) {
          num = vref[i].second;
        }
      }
      num = int(num) + 1;
      vref.push_back(make_pair(ref, num));
      ref.push_back(num);
    }
    else {
      num = int(num) + 1;
      vref.push_back(make_pair(ref, num));
      ref.push_back(num);
    }
    return ref;
}

vector<pair<int, string> > Textos::calc_vec_freq(Text& text) {
    vector<pair<int, string> > aux;
    map<string, int> freq = text.obtenir_freq();
    map<string, int>::iterator it;
    while (not freq.empty()) {
        int i = 0;
        map<string, int>::iterator it2;
        for (it = freq.begin(); it != freq.end(); ++it) {
            if (it->second > i) {
                i = it->second;
                it2 = it;
            }
            else if (it->second == i) {
                if (it->first.size() < it2->first.size()) {
                  it2 = it;
                }
                else if ((it->first.size() == it2->first.size()) and (it->first < it2->first)){
                    it2 = it;
                }
            }
        }
        aux.push_back(make_pair(it2->second, it2->first));
        freq.erase(it2);
    }
    return aux;
}

void Textos::canvi_freq_v(string p, string q) {
    bool trobat = false;
    int i = 0;
    while (not trobat and i < ultim.freq_v.size()) {
        if (ultim.freq_v[i].second == p){
            trobat = true;
            ultim.freq_v[i].second = q;
        }
        ++i;
    }
}

Textos::Textos() {
    nAutor = 0;
    nText = 0;
    ultim.esta = false;
}

bool Textos::esta_autor(string& autor) {
    map<string, list<Text> >::iterator it = textos.find(autor);
    if (it != textos.end()) return true;
    else return false;
}

void Textos::triar_text_par(vector<string>& paraules) {
    map<string, list<Text> >::iterator it = textos.begin();
    bool trobat, trobat2;
    trobat = trobat2 = false;
    ultim.esta = false;
    while (not trobat2 and it != textos.end()) {
        list<Text>::iterator t_it = it->second.begin();
        while (not trobat2 and t_it != it->second.end()) {
          vector<string> aut_tit;
          vector<string> tit = (*t_it).consultar_vtitol();
          int n = tit.size();
          for (int i = 0; i < n; ++i) {
            string s = tit[i];
            int m = s.size() - 1;
            if ((s[m] >= 'a' and s[m] <= 'z') or (s[m] >= 'A' and s[m] <= 'Z') or (s[m] >= '0' and s[m] <= '9')) {
              aut_tit.push_back(s);
            }
            else {
              string aux;
              for (int i = 0; i < m; ++i) aux.push_back(s[i]);
              aut_tit.push_back(aux);
            }
          }
          vector<string> aut = (*t_it).consultar_vautor();
          n = aut.size();
          for (int i = 0; i < n; ++i) {
            string s = aut[i];
            int m = s.size() - 1;
            if ((s[m] >= 'a' and s[m] <= 'z') or (s[m] >= 'A' and s[m] <= 'Z') or (s[m] >= '0' and s[m] <= '9')) {
              aut_tit.push_back(s);
            }
            else {
              string aux;
              for (int i = 0; i < m; ++i) aux.push_back(s[i]);
              aut_tit.push_back(aux);
            }
          }
          vector<string> par;
          int npar = paraules.size();
          int nau_ti = aut_tit.size();
          for (int i = 0; i < npar; ++i){
            bool hi_es = false;
            for (int j = 0; j < nau_ti; ++j) {
              if (paraules[i] == aut_tit[j]) hi_es = true;
            }
            if (not hi_es) par.push_back(paraules[i]);
          }
          if (par.size() == 0) {
            if (trobat) trobat2 = true;
            trobat = true;
            if (trobat and not ultim.esta){
                ultim.ult = make_pair(it->first, *t_it);
                ultim.freq_v = calc_vec_freq(*t_it);
                ultim.esta = true;
            }
          }
          else {
            if (trobat) trobat2 = (*t_it).te_paraules(par);
            if ((*t_it).te_paraules(par)) trobat = true;
            if (trobat and not ultim.esta){
                ultim.ult = make_pair(it->first, *t_it);
                ultim.freq_v = calc_vec_freq(*t_it);
                ultim.esta = true;
            }
          }
            ++t_it;
        }
        ++it;
    }
    if (trobat2) {
      ultim.esta = false;
      cout << "error" << endl;
    }
    if (not trobat) cout << "error" << endl;
}

void Textos::textos_autor(string& autor) {
    map<string, list<Text> >::iterator it = textos.find(autor);
    list<Text>::iterator it_l = it->second.begin();
    while (it_l != it->second.end()) {
        cout << '"' << (*it_l).consultar_titol() << '"' << endl;
        ++it_l;
    }
}

void Textos::consulta_autor() {
    if (not ultim.esta) cout << "error" << endl;
    else cout << ultim.ult.first << endl;
}

void Textos::consulta_nFrases() {
    if (ultim.esta) cout << ultim.ult.second.consultar_nFrases() << endl;
    else cout << "error" << endl;
}

void Textos::consulta_nParaules() {
  if (ultim.esta) cout << ultim.ult.second.consultar_nParaules() << endl;
  else cout << "error" << endl;
}

void Textos::obtenir_frases(int x, int y) {
    if (not ultim.esta or ultim.ult.second.consultar_nFrases() < y) cout << "error" << endl;
    else {
        vector<Frase> fra;
        fra = ultim.ult.second.obtenir_frases(x, y);
        int m = fra.size();
        for (int i = 0; i < m; ++i) {
          cout <<  x + i << ' ';
          fra[i].escriure();
        }
    }
}

void Textos::obtenir_freq() {
    if (not ultim.esta) cout << "error" << endl;
    else {
        int n = ultim.freq_v.size();
        for (int i = 0; i < n; ++i) {
          cout << ultim.freq_v[i].second << ' ' << ultim.freq_v[i].first << endl;
        }
    }
}

void Textos::obtenir_frases_par(vector<string>& paraules) {
    if (not ultim.esta) cout << "error" << endl;
    else {
      ultim.ult.second.sec_paraules(paraules);
    }
}

void Textos::afegir_text(string& autor, Text& text) {
    map<string, list<Text> >::iterator it;
    it = textos.find(autor);
    if (it != textos.end()){
        list<Text>::iterator it2 = it->second.begin();
        string titol = text.consultar_titol();
        bool esta = false;
        while (not esta and it2 != it->second.end()) {
          if (titol == (*it2).consultar_titol()) esta = true;
          else ++it2;
        }
        if (esta) cout << "error" << endl;
        else {
          bool fi = true;
          while (fi and it2 != it->second.end()){
              if (text.consultar_titol() < (*it2).consultar_titol()) {
                it->second.insert(it2, text);
                fi = false;
              }
              else ++it2;
            }
            if (fi) it->second.insert(it2, text);
            ++nText;
          }
        }
        else {
          list<Text> ll_tex;
          list<Text>::iterator it3 = ll_tex.begin();
          ll_tex.insert(it3, text);
          textos.insert(make_pair(autor, ll_tex));
          ++nAutor;
          ++nText;
        }
}


void Textos::eliminar_text() {
    if (not ultim.esta) cout << "error" << endl;
    else {
        map<string, list<Text> >::iterator it_m = textos.find(ultim.ult.first);
        list<Text>::iterator it_l = it_m->second.begin();
        bool borrat = false;
        while (not borrat and it_l != it_m->second.end()) {
            Text t = *it_l;
            string tit2 = (*it_l).consultar_titol();
            if (ultim.ult.second.consultar_titol() == (*it_l).consultar_titol()) {
                it_l = it_m->second.erase(it_l);
                borrat = true;
            }
        }
        --nText;
        if (it_m->second.empty()) {
            textos.erase(it_m);
            --nAutor;
        }
        ultim.esta = false;
  }
}

void Textos::cambiar_paraula(string p, string q) {
    if (not ultim.esta) cout << "error" << endl;
    else if (p != q) {
        ultim.ult.second.cambiar_paraula(p, q);
        map<string, list<Text> >::iterator it_m = textos.find(ultim.ult.first);
        list<Text>::iterator it_l = it_m->second.begin();
        bool cambiat = false;
        while (not cambiat and it_l != it_m->second.end()) {
            if (ultim.ult.second.consultar_titol() == (*it_l).consultar_titol()) {
                (*it_l).cambiar_paraula(p, q);
            }
            ++it_l;
        }
        ultim.freq_v = calc_vec_freq(ultim.ult.second);
        //canvi_freq_v(p, q); //crear-la
    }
}

void Textos::afegir_cita(int x, int y){
    if (ultim.esta) {
      if (x > ultim.ult.second.consultar_nFrases() or y > ultim.ult.second.consultar_nFrases()) {
        cout << "error" << endl;
      }
      else {
        vector<Frase> v_fra = ultim.ult.second.obtenir_frases(x, y);
        string ref = calcular_ref(ultim.ult.first);
        map<string, Cita>::iterator it = Cites.begin();
        bool trobat = false;
        while (not trobat and it != Cites.end()) {
          if (it->second.consultar_Titol() == ultim.ult.second.consultar_titol() and it->second.consultar_Autor() == ultim.ult.first) {
            if (it->second.consultar_fra_in() == x  and it->second.consultar_fra_fi() == y) trobat = true;
          }
          ++it;
        }
        if (not trobat) {
          Cita cita;
          cita.afegir_frases(v_fra, x, y);
          cita.afegir_tit_aut(ultim.ult.second.consultar_titol(), ultim.ult.first);
          Cites.insert(make_pair(ref, cita));
        }
        else {
          vref.pop_back();
          cout << "error" << endl;
        }
      }
    }
    else cout << "error" << endl;
}

void Textos::eliminar_cita(string& referencia) {
    map<string, Cita>::iterator it;
    it = Cites.find(referencia);
    if (it == Cites.end()) cout << "error" << endl;
    else it = Cites.erase(it);
}

void Textos::escriure() {
    map<string, list<Text> >::iterator it;
    for (it = textos.begin(); it != textos.end(); ++it) {
        list<Text>::iterator it2;
        for (it2 = it->second.begin(); it2 != it->second.end(); ++it2) {
            cout << it->first << ' ';
            cout << '"' << (*it2).consultar_titol() << '"' << endl;
        }
    }
}

bool Textos::tractar_pila_exp(stack<string>& s, Frase& f){
    if (s.top() == "{") {
      s.pop();
      return true;
    }
    else {
      if((s.top() == "is true") or (f.te_paraula(s.top()))) {
        s.pop();
        return tractar_pila_exp(s, f);
      }
      else {
        return false;
      }
    }
}

bool Textos::tractar_pila_par(stack<string>& s, Frase& f) {
  bool c1, c2;
  bool primer = true;
  string aux;
  string trac = "enable";
  while (s.top() != "(") {
    if(primer) {
      primer = false;
      c1 = ((s.top() == "is true") or (f.te_paraula(s.top())));
      aux = s.top();
    }
    else if (s.top() == "&" or s.top() == "|") trac = s.top();
    else c2 = (s.top() == "is true") or (f.te_paraula(s.top()));
    s.pop();
  }
  if (trac == "enable") {
    return (aux == "is true") or (f.te_paraula(aux));
  }
  else {
    if (trac == "|") return c1 or c2;
    else return c1 and c2;
  }
}

void Textos::escriure_fra_exp(string linia) {
  if(ultim.esta) {
    int mida = ultim.ult.second.consultar_nFrases();
    vector<Frase> f = ultim.ult.second.obtenir_frases(1, mida);
    for (int j = 0; j < mida; ++j) {
      istringstream iss(linia);
      string m;
      iss >> m;
      stack<string> s;
      while (iss >> m and m != "?") {
        string aux;
        int mid = m.size();
        int i = 0;
        while(i < mid) {
          while (m[i] == '(' or m[i] == '{') {
            if (m[i] == '(') s.push("(");
            else s.push("{");
            ++i;
          }
          while (i < mid and m[i] != ')' and m[i] != '}') {
            aux.push_back(m[i]);
            ++i;
          }
          s.push(aux);
          while (i < mid) {
            bool resultat;
            if (m[i] == '}') {
              resultat = tractar_pila_exp(s, f[j]);
              if(resultat) s.push("is true");
              else s.push("is false");
            }
            else {
              resultat = tractar_pila_par(s, f[j]);
              if(resultat) s.push("is true");
              else s.push("is false");
            }
            ++i;
          }
        }
      }
      if (s.top() == "is true") {
        cout << j+1 << ' ';
        f[j].escriure();
      }
    }
  }
  else cout << "error" << endl;
}

void Textos::escriure_autors() {
    map<string, list<Text> >::iterator it;
    for (it = textos.begin(); it != textos.end(); ++it) {
        cout << it->first;
        int nPar = 0;
        int nFra = 0;
        int nTex = 0;
        list<Text>::iterator it2;
        for (it2 = it->second.begin(); it2 != it->second.end(); ++it2) {
            ++nTex;
            nPar += (*it2).consultar_nParaules();
            nFra += (*it2).consultar_nFrases();
        }
        cout << ' ' << nTex << ' ' << nFra << ' ' << nPar << endl;
    }
}

void Textos::escriure_info() {
  if (ultim.esta) {
    cout << ultim.ult.first << ' ' << '"' << ultim.ult.second.consultar_titol() << '"';
    cout << ' ' << ultim.ult.second.consultar_nFrases() << ' ' << ultim.ult.second.consultar_nParaules() << endl;
    map<string, Cita>::iterator it;
    cout << "Cites Associades:" << endl;
    for (it = Cites.begin(); it != Cites.end(); ++it) {
        if (it->second.consultar_Autor() == ultim.ult.first) {
            if (it->second.consultar_Titol() == ultim.ult.second.consultar_titol()) {
                cout << it->first << endl;
                vector<Frase> frases = it->second.consultar_cita();
                int x = it->second.consultar_fra_in();
                for (int i = 0; i < frases.size(); ++i) {
                    cout << x << ' ';
                    frases[i].escriure();
                    ++x;
                }
            }
        }
    }
  }
  else cout << "error" << endl;
}

void Textos::escriure_contingut() {
    if (ultim.esta) ultim.ult.second.escriure();
    else cout << "error" << endl;
}

void Textos::escriure_cita_ref(string& ref) {
    map<string, Cita>::iterator it;
    it = Cites.find(ref);
    if (it != Cites.end()) {
      cout << it->second.consultar_Autor() << ' ' << '"';
      cout << it->second.consultar_Titol() << '"' << endl;
      cout << it->second.consultar_fra_in() << '-' << it->second.consultar_fra_fi() << endl;
      vector<Frase> frases = it->second.consultar_cita();
      int x = it->second.consultar_fra_in();
      for (int i = 0; i < frases.size(); ++i) {
          cout << x << ' ';
          frases[i].escriure();
          ++x;
      }
  }
  else cout << "error" << endl;
}

void Textos::escriure_cita_autor(string& autor) {
    map<string, Cita>::iterator it;
    for (it = Cites.begin(); it != Cites.end(); ++it) {
        if (autor == it->second.consultar_Autor()) {
            cout << it->first << endl;
            vector<Frase> cita = it->second.consultar_cita();
            int x = it->second.consultar_fra_in();
            for (int j = 0; j < cita.size(); ++j) {
                cout << x << ' ';
                cita[j].escriure();
                ++x;
            }
            cout << '"' << it->second.consultar_Titol() << '"' << endl;
        }
    }
}

void Textos::escriure_cites() {
  if (ultim.esta) {
    string aut = ultim.ult.first;
    string tit = ultim.ult.second.consultar_titol();
    map<string, Cita>::iterator it;
    for (it = Cites.begin(); it != Cites.end(); ++it){
        if (it->second.consultar_Autor() == ultim.ult.first) {
            if (it->second.consultar_Titol() == ultim.ult.second.consultar_titol()) {
                cout << it->first << endl;
                vector<Frase> frases = it->second.consultar_cita();
                int x = it->second.consultar_fra_in();
                for (int i = 0; i < frases.size(); ++i) {
                    cout << x << ' ';
                    frases[i].escriure();
                    ++x;
                }
                cout << it->second.consultar_Autor() << ' ' << '"';
                cout << it->second.consultar_Titol() << '"' << endl;
            }
        }
    }
  }
  else cout << "error" << endl;
}

void Textos::escriure_totes_cites() {
    map<string, Cita>::iterator it;
    for (it = Cites.begin(); it != Cites.end(); ++it){
        vector<Frase> cita = it->second.consultar_cita();
        cout << it->first << endl;
        int x, y;
        x = it->second.consultar_fra_in();
        y = it->second.consultar_fra_fi();
        for (int u = x; u <= y; ++u) {
            cout << u << ' ';
            cita[u - x].escriure();
        }
        cout << it->second.consultar_Autor() << ' ';
        cout << '"' << it->second.consultar_Titol() << '"' << endl;
    }
}
